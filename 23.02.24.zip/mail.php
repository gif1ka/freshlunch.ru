<?php

$project_name = "Заявка с  сайта frnlanch.ru";
$admin_email  = "info@freshlunch.ru";
$from         = "zayavka@frnlanch.ru";
$form_subject = "Заявка с сайта frnlanch.ru";

foreach ( $_POST as $key => $value ) {
	if ( $value != "" && $key != "project_name" && $key != "admin_email" && $key != "form_subject" ) {
	$message .= "
		" . ( ($c = !$c) ? '<tr>':'<tr style="background-color: #f8f8f8;">' ) . "
			<td style='padding: 10px; border: #e9e9e9 1px solid;'><b>$key</b></td>
			<td style='padding: 10px; border: #e9e9e9 1px solid;'>$value</td>
		</tr>
		";
	}
}

$message = "<table style='width: 100%;'>$message</table>";

function adopt($text) {
	return '=?UTF-8?B?'.base64_encode($text).'?=';
}

$headers = "MIME-Version: 1.0" . PHP_EOL .
"Content-Type: text/html; charset=utf-8" . PHP_EOL .
'From: '.adopt($project_name).' <'.$from.'>' . PHP_EOL .
'Reply-To: '.$from.'' . PHP_EOL;



mail($admin_email, adopt($form_subject), $message, $headers );



// Заявки в тг 

$token = "5816697936:AAEAcHphQYrsLM6mtGTODAckm45HFHJrvQU"; // Тут пишем токен
$chat_id = "-1001682526269"; // Тут пишем ID группы, куда будут отправляться сообщения
$sitename = "freshlunch.ru"; //Указываем название сайта


if ($_POST['Отзыв'] == 'Да') {
    $comment = ($_POST['Комментарий']);
    $name = ($_POST['Имя']);
    $ocen = ($_POST['Оценка']);
    $mail = ($_POST['Почта']);
    $where = ($_POST['Откуда']);
    
//Собираем в массив то, что будет передаваться боту
    $arr = array(
      'Заказ с сайта ' => $sitename,
      'Откуда:' => $where,
      'Оценка:' => $ocen,
      'Имя:' => $name,
      'Комментарий:' => $comment,
      'Почта:' => $mail,
    );}


    if ($_POST['Звонок'] == 'Да') {
    $name = ($_POST['Имя']);
    $phone = ($_POST['Телефон']);
    $where = ($_POST['Откуда']);
    
//Собираем в массив то, что будет передаваться боту
    $arr = array(
      'Заказ с сайта ' => $sitename,
      'Откуда:' => $where,
      'Телефон:' => $phone,
      'Имя:' => $name,
    );}

    if ($_POST['Доставка'] == 'Да') {
    $name = ($_POST['Имя']);
    $mail = ($_POST['Email']);
    $ulica = ($_POST['Улица']);
    $kv = ($_POST['Номер_квартиры']);
    $phone = ($_POST['Телефон']);
    $where = ($_POST['Откуда']);
    
//Собираем в массив то, что будет передаваться боту
    $arr = array(
      'Заказ с сайта ' => $sitename,
      'Откуда:' => $where,
      'Телефон:' => $phone,
      'Имя:' => $name,
      'Email:' => $mail,
      'Улица:' => $ulica,
      'Номер_квартиры:' => $kv,
    );}


foreach($arr as $key => $value) {
  $txt .= "<b>".$key."</b> ".$value."%0A";
};

$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");



