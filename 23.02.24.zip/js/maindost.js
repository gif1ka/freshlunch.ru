jQuery(document).ready(function(){

  	$("#forma-zakazafin").submit(function() {

		var th = $(this);
		th.children().hide();
        th.append('<p style="color: #fff;" class="otpravka-zayavki">Отправка данных...</p>');
        
		let forma_zakaza_data = $('#forma-zakazafin').serializeArray();
		let rationLS = JSON.parse(localStorage.getItem("rationLS"));
		let dishesLS = JSON.parse(localStorage.getItem("dishesLS"));
		let promoCode = localStorage.getItem("promoCode");
		let totalSum = localStorage.getItem("totalSum");
		let forma_transf_data = {};
		
		localStorage.setItem('rationLS', JSON.stringify([]));
		localStorage.setItem('dishesLS', JSON.stringify([]));
		localStorage.setItem('totalSum', "");
		localStorage.setItem('promoCode', "");
		
		forma_transf_data['comment'] = '';
        forma_transf_data['address_text'] = '';
        
        if (rationLS.length > 0)  {
            forma_transf_data['diet_name'] = rationLS[0].type;
            forma_transf_data['tariff_name'] = rationLS[0].calorie;
            forma_transf_data['days_count'] = rationLS[0].validity;
        }
        forma_transf_data['price'] = totalSum;
        if (promoCode != null && promoCode != "") forma_transf_data['promocode'] = promoCode;
        
        for (const element of forma_zakaza_data) {
            if (element.name == "Имя") forma_transf_data['name'] = element.value;
            if (element.name == "Телефон") forma_transf_data['phone'] = element.value;
            if (element.name == "Улица") forma_transf_data['address_text'] += (" улица " + element.value);
            if (element.name == "Номер_квартиры") forma_transf_data['address_text'] += (" номер квартиры " + element.value);
            if (element.name == "Email") forma_transf_data['comment'] += (" email " + element.value);
        }
        if (rationLS.length > 0)  {
            forma_transf_data['comment'] += ("\nРационы:");
            for (const diet of rationLS) {
                forma_transf_data['comment'] += ("\n" + JSON.stringify(diet));
            }
        }
        if (dishesLS.length > 0)  {
            forma_transf_data['comment'] += ("\nБлюда:");
            for (const dish of dishesLS) {
                forma_transf_data['comment'] += ("\n" + JSON.stringify(dish));
            }
        }
        
		$.ajax({
			type: "POST",
			url: "../private-crm.php",
			data: forma_transf_data
		});
		
		$.ajax({
			type: "POST",
			url: "../mail.php",
			data: th.serialize()
		}).done(function() {
			 window.location = "../spasibo.html";
    });
    return false;
	});

});