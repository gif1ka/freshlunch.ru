
jQuery(document).ready(function(){

	// toogle-mnu
	let menuBtn = document.querySelector('.menu-btn');
  let menu = document.querySelector('.menu');

  menuBtn.addEventListener('click', function(){
	menuBtn.classList.toggle('active');
	menu.classList.toggle('active');
    })


	// pageScroll2id.min.js
	$(".header-line li a, .btn-scr").mPageScroll2id({
		ofset : 0,
		scrollSpeed : 750
	});
	// end pageScroll2id.min.js
		//popup jquery.magnific-popup.min.js
	$(".open-popup").magnificPopup({
		mainClass: 'my-mfp-zoom-in',
		removalDelay: 0,
		type: 'inline', 
	});


		

 //Изменение цены и БЖУ при нажатии
   $(".click1200").click(function(){
    $(".font1500").removeClass("font1500active");
    $(".font1800").removeClass("font1800active");
    $(".cena1500").removeClass("cena1500active");
    $(".cena1800").removeClass("cena1800active");
    $(".font1200").addClass("font1200active");
    $(".cena1200").addClass("cena1200active");
    $(".skidka2").addClass("input1200");
  });

  $(".click1500").click(function(){
    $(".font1200").removeClass("font1200active");
    $(".font1800").removeClass("font1800active");
    $(".cena1200").removeClass("cena1200active");
    $(".cena1800").removeClass("cena1800active");
    $(".font1500").addClass("font1500active");
    $(".cena1500").addClass("cena1500active");

  });
  $(".click1800").click(function(){
    $(".font1200").removeClass("font1200active");
    $(".font1500").removeClass("font1500active");
    $(".cena1200").removeClass("cena1200active");
    $(".cena1500").removeClass("cena1500active");
    $(".font1800").addClass("font1800active");
    $(".cena1800").addClass("cena1800active");
  });


   $(".click1200mor").click(function(){
    $(".font1500mor").removeClass("font1500activemor");
    $(".font1800mor").removeClass("font1800activemor");
    $(".cena1500mor").removeClass("cena1500activemor");
    $(".cena1800mor").removeClass("cena1800activemor");
    $(".font1200mor").addClass("font1200activemor");
    $(".cena1200mor").addClass("cena1200activemor");
  });
    $(".click1500mor").click(function(){
    $(".font1200mor").removeClass("font1200activemor");
    $(".font1800mor").removeClass("font1800activemor");
    $(".cena1200mor").removeClass("cena1200activemor");
    $(".cena1800mor").removeClass("cena1800activemor");
    $(".font1500mor").addClass("font1500activemor");
    $(".cena1500mor").addClass("cena1500activemor");
  });
     $(".click1800mor").click(function(){
    $(".font1200mor").removeClass("font1200activemor");
    $(".font1500mor").removeClass("font1500activemor");
    $(".cena1200mor").removeClass("cena1200activemor");
    $(".cena1500mor").removeClass("cena1500activemor");
    $(".font1800mor").addClass("font1800activemor");
    $(".cena1800mor").addClass("cena1800activemor");
  });

//блок со скидкой при нажатии
    $(".skidka12").click(function(){
    $(".skidka18dney").removeClass("skidkaactive");
    $(".skidka24dny").removeClass("skidkaactive");
    $(".skidka12dney").addClass("skidkaactive");
  });
    $(".skidka18").click(function(){
    $(".skidka12dney").removeClass("skidkaactive");
    $(".skidka24dny").removeClass("skidkaactive");
    $(".skidka18dney").addClass("skidkaactive");
  });
    $(".skidka24").click(function(){
    $(".skidka12dney").removeClass("skidkaactive");
    $(".skidka18dney").removeClass("skidkaactive");
    $(".skidka24dny").addClass("skidkaactive");
  });
    $(".skidka6").click(function(){
    $(".skidka12dney").removeClass("skidkaactive");
    $(".skidka18dney").removeClass("skidkaactive");
    $(".skidka24dny").removeClass("skidkaactive");
  });
    $(".skidka2").click(function(){
    $(".skidka12dney").removeClass("skidkaactive");
    $(".skidka18dney").removeClass("skidkaactive");
    $(".skidka24dny").removeClass("skidkaactive");
  });



  //Табы
  $(".tab-item").not(":first").hide();
  $(".tab-wrap").click(function() {
    $(".tab-wrap").removeClass("tab-active").eq($(this).index()).addClass("tab-active");
    $(".tab-item").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active"); 

   //Табы-колории
  $(".tab-item-colorii").not(":first").hide();
  $(".tab-wrap-colorii").click(function() {
    $(".tab-wrap-colorii").removeClass("tab-active-colorii").eq($(this).index()).addClass("tab-active-colorii");
    $(".tab-item-colorii").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-colorii");

  //Табы-доставка
  $(".tab-item-dost").not(":first").hide();
  $(".tab-wrap-dost").click(function() {
    $(".tab-wrap-dost").removeClass("tab-active-dost").eq($(this).index()).addClass("tab-active-dost");
    $(".tab-item-dost").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-dost"); 

  //Табы-дни
  $(".tab-item-dni").not(":first").hide();
  $(".tab-wrap-dni").click(function() {
    $(".tab-wrap-dni").removeClass("tab-active-dni").eq($(this).index()).addClass("tab-active-dni");
    $(".tab-item-dni").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-dni"); 

  $(".tab-item-dni1500").not(":first").hide();
  $(".tab-wrap-dni1500").click(function() {
    $(".tab-wrap-dni1500").removeClass("tab-active-dni1500").eq($(this).index()).addClass("tab-active-dni1500");
    $(".tab-item-dni1500").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-dni1500"); 

  $(".tab-item-dni1800").not(":first").hide();
  $(".tab-wrap-dni1800").click(function() {
    $(".tab-wrap-dni1800").removeClass("tab-active-dni1800").eq($(this).index()).addClass("tab-active-dni1800");
    $(".tab-item-dni1800").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-dni1800"); 

  //Табы-колории-морское
  $(".tab-item-colorii-mr").not(":first").hide();
  $(".tab-wrap-colorii-mr").click(function() {
    $(".tab-wrap-colorii-mr").removeClass("tab-active-colorii-mr").eq($(this).index()).addClass("tab-active-colorii-mr");
    $(".tab-item-colorii-mr").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-colorii-mr");

  $(".tab-item-dost-mr").not(":first").hide();
  $(".tab-wrap-dost-mr").click(function() {
    $(".tab-wrap-dost-mr").removeClass("tab-active-dost-mr").eq($(this).index()).addClass("tab-active-dost-mr");
    $(".tab-item-dost-mr").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-dost-mr"); 

   $(".tab-item-dni-mr").not(":first").hide();
  $(".tab-wrap-dni-mr").click(function() {
    $(".tab-wrap-dni-mr").removeClass("tab-active-dni-mr").eq($(this).index()).addClass("tab-active-dni-mr");
    $(".tab-item-dni-mr").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-dni-mr"); 

  $(".tab-item-dni1500-mr").not(":first").hide();
  $(".tab-wrap-dni1500-mr").click(function() {
    $(".tab-wrap-dni1500-mr").removeClass("tab-active-dni1500-mr").eq($(this).index()).addClass("tab-active-dni1500-mr");
    $(".tab-item-dni1500-mr").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-dni1500-mr"); 

  $(".tab-item-dni1800-mr").not(":first").hide();
  $(".tab-wrap-dni1800-mr").click(function() {
    $(".tab-wrap-dni1800-mr").removeClass("tab-active-dni1800-mr").eq($(this).index()).addClass("tab-active-dni1800-mr");
    $(".tab-item-dni1800-mr").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-dni1800-mr"); 

  //Табы-галлерея
  $(".tab-item-galery").not(":first").hide();
  $(".tab-wrap-galery").click(function() {
    $(".tab-wrap-galery").removeClass("tab-active-galery").eq($(this).index()).addClass("tab-active-galery");
    $(".tab-item-galery").hide().eq($(this).index()).fadeIn(1000);
  }).eq(0).addClass("tab-active-galery"); 

  //карусель
  $(".owl-carousel").owlCarousel({
    loop:true,
    items:4,
    nav:true,
    // autoplay:true,
    autoplayTimeout:10500,
    autoplayHoverPause:true,
    smartSpeed:500,
    navText:"",
    dots: false,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        579:{
            items:2,
            nav:true
        },
        768:{
            items:4,
            nav:false
        },
        1000:{
            items:4,
            nav:true
        }
    }
});




	//Аккардеон для ответов на вопросы
	$(".accordeon .ans").hide().prev().click(function() {
		$(this).parents(".accordeon").find(".ans").not(this).slideUp().prev().removeClass("active");
		$(this).next().not(":visible").slideDown().prev().addClass("active");
	});
	$(".accordeon .active").click();

	// Форма отправки
	$("#otziv").submit(function() { 
		var th = $(this);
		th.children().hide();
		th.children('button.mfp-close').show();
		th.append('<p class="otpravka-zayavki">Отправка данных...</p>');
		$.ajax({
			type: "POST",
			url: "mail.php",
			data: th.serialize()
		}).done(function() {
			$(this).find("input").val("");
			setTimeout(function() {
				th.children().hide();
				th.children('button.mfp-close').show();
				th.append('<p class="zayavka-otpravlena">Спасибо! Нам очень важна ваша обратная связь.</p>');
			}, 500);
		});
		return false;
	});

	$("#forma-zakaza, #forma-zakazafin, #calback").submit(function() {


		var th = $(this);
		localStorage.setItem('rationLS', JSON.stringify([]));
		localStorage.setItem('dishesLS', JSON.stringify([]));
		
		Cart.render(true);
		promoChecker()
		
		let forma_zakaza_data = $('#forma-zakaza, #forma-zakazafin, #calback').serializeArray();
		let forma_transf_data = {};
		
		forma_transf_data['comment'] = '';
        forma_transf_data['address_text'] = '';
        
        for (const element of forma_zakaza_data) {
            if (element.name.includes("Тип_рациона")){
                forma_transf_data['diet_name'] = element.value;
            }
            if (element.name.includes("лории")){
                forma_transf_data['comment'] +=' Калорийность ';
                forma_transf_data['comment'] += element.value;
            }
            if (element.name.includes("Срок")) {
                forma_transf_data['days_count'] = element.value;
            }
            if (element.name.includes("Цена")) {
                forma_transf_data['price'] = element.value;
            }
            if (element.name == "Имя") forma_transf_data['name'] = element.value;
            if (element.name == "Телефон") forma_transf_data['phone'] = element.value;
            if (element.name == "Промокод") forma_transf_data['promocode'] = element.value;
            if (element.name == "Улица") forma_transf_data['address_text'] += (" улица " + element.value);
            if (element.name == "Номер_квартиры") forma_transf_data['address_text'] += (" номер квартиры " + element.value);
            if (element.name == "Email") forma_transf_data['comment'] += (" email " + element.value);
        }
        
		$.ajax({
			type: "POST",
			url: "../private-crm.php",
			data: forma_transf_data
		});
		
		$.ajax({
			type: "POST",
			url: "../mail.php",
			data: th.serialize()
		}).done(function() {
			 window.location = "../spasibo.html";
    });
    return false;
	});
	

 $("#phone").mask("+7 (999) 999 - 9999",{autoclear: false});
 $("#phone1").mask("+7 (999) 999 - 9999",{autoclear: false});



//promo

const promoCode = {
	"NEWFRESH10": 10,
}

function promoChecker() {
	console.log("promo")
	Cart.render()
	const promoInput = document.getElementById("promo-input");
	let percent = 0;
	for (const key in promoCode) {
		if (promoInput.value === key) {
			percent = promoCode[key]
			localStorage.setItem('promoCode', key);
		}
	}
	if (!percent) {
		Cart.render()
		if (promoInput.value !== "") {
			document.getElementById("errorMessage").innerText = "Такого промокода нет. Проверьте, всё ли верно, или введите другой";
		}
		return
	}
	document.getElementById("errorMessage").innerText = "";
	let sum = parseInt($(".summa-count").text().replace(/\s/g, ''), 10)
	let totalSum = Math.floor(sum - (sum * (percent / 100)))
	localStorage.setItem('totalSum', totalSum);
	$(".summa-count").text(totalSum.toLocaleString())
}

document.getElementById("promo-input").addEventListener("input", promoChecker);


// Рацион
	const Ration = {
		getCurrentCalorie(activeClass) {
			const text = document.querySelector(`.btn-colori.${activeClass}`).innerText
			return parseInt(text)
		},

		getCurrentValidity(activeClass) {
			const activeValidity = document.querySelector(`.btn-srok.${activeClass}`).classList[4]
			const validity = activeValidity.match(/\d+/)
			return parseInt(validity[0])
		},

		findRation(rations, calorie, validity) {
			return (rations.find(ration =>
				ration.calorie === calorie &&
				ration.validity === validity))
		}
	}

	const ClassicRation = {
		rations: [
			{ id: 'ration01', type: 'Классический', calorie: 1200, validity: 2,  price: 1285 },
			{ id: 'ration02', type: 'Классический', calorie: 1200, validity: 6,  price: 1265 },
			{ id: 'ration03', type: 'Классический', calorie: 1200, validity: 12, price: 1250 },
			{ id: 'ration04', type: 'Классический', calorie: 1200, validity: 18, price: 1225 },
			{ id: 'ration05', type: 'Классический', calorie: 1200, validity: 24, price: 1192 },

			{ id: 'ration06', type: 'Классический', calorie: 1500, validity: 2,  price: 1290 },
			{ id: 'ration07', type: 'Классический', calorie: 1500, validity: 6,  price: 1260 },
			{ id: 'ration08', type: 'Классический', calorie: 1500, validity: 12, price: 1240 },
			{ id: 'ration09', type: 'Классический', calorie: 1500, validity: 18, price: 1220 },
			{ id: 'ration10', type: 'Классический', calorie: 1500, validity: 24, price: 1200 },

			{ id: 'ration11', type: 'Классический', calorie: 1800, validity: 2,  price: 1400 },
			{ id: 'ration12', type: 'Классический', calorie: 1800, validity: 6,  price: 1380 },
			{ id: 'ration13', type: 'Классический', calorie: 1800, validity: 12, price: 1360 },
			{ id: 'ration14', type: 'Классический', calorie: 1800, validity: 18, price: 1340 },
			{ id: 'ration15', type: 'Классический', calorie: 1800, validity: 24, price: 1320 },
		],
		calorieActiveClass: "tab-active-colorii",
		validityActiveClass: "tab-active-dost",

		getCurrent() {
			const calorie = Ration.getCurrentCalorie(this.calorieActiveClass)
			const validity = Ration.getCurrentValidity(this.validityActiveClass)
			return Ration.findRation(this.rations, calorie, validity)
		},
	}

	const MarineRation = {
		rations: [
			{ id: 'ration16', type: 'Морской', calorie: 1200, validity: 2,  price: 1395 },
			{ id: 'ration17', type: 'Морской', calorie: 1200, validity: 6,  price: 1380 },
			{ id: 'ration18', type: 'Морской', calorie: 1200, validity: 12, price: 1360 },
			{ id: 'ration19', type: 'Морской', calorie: 1200, validity: 18, price: 1340 },
			{ id: 'ration20', type: 'Морской', calorie: 1200, validity: 24, price: 1320 },

			{ id: 'ration21', type: 'Морской', calorie: 1500, validity: 2,  price: 1455 },
			{ id: 'ration22', type: 'Морской', calorie: 1500, validity: 6,  price: 1430 },
			{ id: 'ration23', type: 'Морской', calorie: 1500, validity: 12, price: 1410 },
			{ id: 'ration24', type: 'Морской', calorie: 1500, validity: 18, price: 1390 },
			{ id: 'ration25', type: 'Морской', calorie: 1500, validity: 24, price: 1385 },

			{ id: 'ration26', type: 'Морской', calorie: 1800, validity: 2,  price: 1585 },
			{ id: 'ration27', type: 'Морской', calorie: 1800, validity: 6,  price: 1570 },
			{ id: 'ration28', type: 'Морской', calorie: 1800, validity: 12, price: 1550 },
			{ id: 'ration29', type: 'Морской', calorie: 1800, validity: 18, price: 1530 },
			{ id: 'ration30', type: 'Морской', calorie: 1800, validity: 24, price: 1510 },
		],
		calorieActiveClass: "tab-active-colorii-mr",
		validityActiveClass: "tab-active-dost-mr",

		getCurrent() {
			const calorie = Ration.getCurrentCalorie(this.calorieActiveClass)
			const validity = Ration.getCurrentValidity(this.validityActiveClass)
			return Ration.findRation(this.rations, calorie, validity)
		},
	}

	function getCurrentRation() {
		const rationType = document.querySelector('.tab-wrap.tab-active').innerText
		if (rationType === "Классический") {
			return ClassicRation.getCurrent()
		}
		if (rationType === "Морской") {
			return MarineRation.getCurrent()
		}
	}

	function updateRationPrice() {
		const ration = getCurrentRation()
		$(".cena").text((ration.validity * ration.price).toLocaleString() + " ₽")
	}

// галерея
	const Dishes = {
		dishes: [
			{ id: 'galerey01', name: 'Салат с говяжьей вырезкой',            price: 350 },
			{ id: 'galerey02', name: 'Салат с хрустящей курицей',            price: 320 },
			{ id: 'galerey03', name: 'Цезарь с курицей',                     price: 330 },
			{ id: 'galerey04', name: 'Салат с креветками',                   price: 420 },
			{ id: 'galerey05', name: 'Паста с морепродуктами',               price: 450 },
			{ id: 'galerey06', name: 'Фетучини с грибами в сливочном соусе', price: 420 },
			{ id: 'galerey07', name: 'Спагетти из говяжьей вырезки',         price: 380 },
			{ id: 'galerey08', name: 'Вок со свининой и лапшой',             price: 380 },
			{ id: 'galerey09', name: 'Поке с лососем',                       price: 550 },
			{ id: 'galerey10', name: 'Поке с креветками',                    price: 520 },
			{ id: 'galerey11', name: 'Поке с тунцом',                        price: 560 },
			{ id: 'galerey12', name: 'Поке с курицей',                       price: 450 },
			{ id: 'galerey13', name: 'Севиче из креветок',                   price: 420 },
			{ id: 'galerey14', name: 'Севиче микс',                          price: 430 },
			{ id: 'galerey15', name: 'Кесадилье до Пойо',                    price: 1200 },
			{ id: 'galerey16', name: 'Буррито де Карне',                     price: 1200 },
		],

		getCurrent() {
		const selectElement = document.getElementById('select-galery');
		const selectedOption = selectElement.options[selectElement.selectedIndex];
		const selectedValue = selectedOption.value;
		const dishes = (this.dishes.find(galerey =>
			galerey.id === selectedValue));
		return dishes
		}
	}

// корзина
	const Cart = {
		render(isPopupClose = true) {
			let rationLS = JSON.parse(localStorage.getItem('rationLS')) || [];
			let dishesLS = JSON.parse(localStorage.getItem('dishesLS')) || [];

			if (rationLS.length === 0 && dishesLS.length === 0 && isPopupClose) {
				$(".card").removeClass("cardactive")
				$.magnificPopup.close();
				return
			}

			let summa = 0;
			let counter = 0;
			$(".head").nextAll('.rez-wrap-all').remove();
			$(".head").nextAll('.text-h1').remove();

			rationLS.forEach(item => {
				summa += item.price * item.validity * item.quantity
				counter += item.quantity
				Cart.rationHTML(item)
			})
			dishesLS.forEach(item => {
				summa += item.price * item.quantity
				counter += item.quantity
				Cart.dishesHTML(item)
			})

			if (rationLS.length === 0) {
				summa += 200
				$(".rez-wrap-all").after($("<div>").addClass("text-h1").text("*Цена доставки блюд, без заказа рациона - 200 руб."))
			}
			localStorage.setItem('totalSum', summa)
			$(".summa-count").text(summa.toLocaleString())
			$(".span-counter").text(counter)

			if (counter > 0) {
				$(".card").addClass("cardactive")
			}
			if (summa < 700) {
				$(".button-form").prop("disabled", true);
				$(".message-form").css("display", "block");
			} else {
				$(".button-form").prop("disabled", false);
				$(".message-form").css("display", "none");
			}
		},

		rationHTML(item) {
			let div = $("<div>").addClass("rez-wrap-all").html(`
				<div class="rez-wrap">
					<p class="res-h">Вид рациона:<span class="racion-name">${item.type}</span></p>
					<input type="hidden" id="typeRation${item._id}" name="Тип_рациона${item._id}" value="${item.type}">
					
					<p class="res-h">Каллорийность:<span>${item.calorie}</span>кКал</p>
					<input type="hidden" id="calorie${item._id}" name="Каллории${item._id}" value="${item.calorie}">
					
					<p class="res-h">Срок действия<br>программы:<span>${item.validity}</span>дня</p>
					<input type="hidden" id="validity${item._id}" name="Срок${item._id}" value="${item.validity}">
				</div>
				<div class="counter-wrap">
					<div class="quan-wrap">
						<div class="minus minus-ration" id="${item._id}"><img src="https://freshlunch.ru/img/bg/minus.png" alt=""></div>
						<span class="quantity">${item.quantity}</span>
						<input type="hidden" id="quantity${item._id}" name="Колличество${item._id}" value="${item.quantity}">
						
						<div class="plus plus-ration" id="${item._id}"><img src="https://freshlunch.ru/img/bg/plus.png" alt=""></div>
					</div>
					
					<div class="result">${(item.price * item.validity * item.quantity).toLocaleString()} P</div>
					<input type="hidden" id="price${item._id}" name="Цена${item._id}" value="${(item.price * item.validity * item.quantity)}">
					<div class="remove" id="${item._id}"><img src="https://freshlunch.ru/img/bg/x.png" alt=""></div>
				</div>`
			);
			$(".head").after(div)
		},

		dishesHTML(item) {
			let div = $("<div>").addClass("rez-wrap-all").html(`
				<div class="rez-wrap">
					<p class="res-h">Блюдо:<span class="bludo-name">${item.name}</span></p>
					<input type="hidden" id="name${item._id}" name="Блюдо${item._id}" value="${item.name}">
				</div>
				<div class="counter-wrap">
						<div class="quan-wrap">
								<div class="minus minus-dishes" id="${item._id}"><img src="https://freshlunch.ru/img/bg/minus.png" alt=""></div>
								<span class="quantity">${item.quantity}</span>
								<input type="hidden" id="quantityD${item._id}" name="КолличествоD${item._id}" value="${item.quantity}">
								<div class="plus plus-dishes" id="${item._id}"><img src="https://freshlunch.ru/img/bg/plus.png" alt=""></div>
						</div>
						<div class="result">${(item.price * item.quantity).toLocaleString()} P</div>
						<input type="hidden" id="priceD${item._id}" name="ЦенаD${item._id}" value="${(item.price * item.quantity)}">
						<div class="remove" id="${item._id}"><img src="https://freshlunch.ru/img/bg/x.png" alt=""></div>
				</div>`
			)
			$(".head").after(div)
		},
		
		addRation() {
			let ration = getCurrentRation()
			let rationLS = JSON.parse(localStorage.getItem('rationLS')) || [];

			let existingRation = []
			rationLS.forEach(obj => {
				if (obj.id === ration.id) {
					existingRation.push(obj);
				}
			});

			const len = existingRation.length
			if (len !== 0 && existingRation[len - 1].quantity < 10) {
				existingRation[len - 1].quantity++
			} else {
				rationLS.push({...ration, quantity: 1, _id: new Date().getTime()});
			}

			localStorage.setItem('rationLS', JSON.stringify(rationLS));
			Cart.render()
			promoChecker()
		},

		addDishes() {
			let dishes = Dishes.getCurrent()
			let dishesLS = JSON.parse(localStorage.getItem('dishesLS')) || [];

			let existingDishes = []
			dishesLS.forEach(obj => {
				if (obj.id === dishes.id) {
					existingDishes.push(obj);
				}
			});

			const len = existingDishes.length
			if (len !== 0 && existingDishes[len - 1].quantity < 10) {
					existingDishes[len - 1].quantity++
			} else {
				dishesLS.push({...dishes, quantity: 1, _id: new Date().getTime()});
			}

			localStorage.setItem('dishesLS', JSON.stringify(dishesLS));
			Cart.render()
			promoChecker()
		},

		addDishesInPage() {
			let dishes = (Dishes.dishes.find(item => item.name === $(".h").text()));
			let dishesLS = JSON.parse(localStorage.getItem('dishesLS')) || [];

			let existingDishes = []
			dishesLS.forEach(obj => {
				if (obj.id === dishes.id) {
					existingDishes.push(obj);
				}
			});

			const len = existingDishes.length
			if (len !== 0 && existingDishes[len - 1].quantity < 10) {
				existingDishes[len - 1].quantity++
			} else {
				dishesLS.push({...dishes, quantity: 1, _id: new Date().getTime()});
			}

			localStorage.setItem('dishesLS', JSON.stringify(dishesLS));
			Cart.render()
			promoChecker()
		},

		removeRation(_id) {
			let rationLS = JSON.parse(localStorage.getItem('rationLS')) || [];
			const indexToDelete = rationLS.findIndex(obj => obj._id === _id);
			if (indexToDelete !== -1) {
				rationLS.splice(indexToDelete, 1);
				localStorage.setItem('rationLS', JSON.stringify(rationLS));
			}
		},

		removeDishes(_id) {
			let dishesLS = JSON.parse(localStorage.getItem('dishesLS')) || [];
			const indexToDelete = dishesLS.findIndex(obj => obj._id === _id);
			if (indexToDelete !== -1) {
				dishesLS.splice(indexToDelete, 1);
				localStorage.setItem('dishesLS', JSON.stringify(dishesLS));
			}
		},
	}

	function updateDishesPrice() {
		const selectedOptionClass = $('#select-galery').val();
		if (selectedOptionClass) {
			const dishes = Dishes.dishes.find(obj => obj.id === selectedOptionClass);
			if (dishes) {
				$(".cena-dishes").text(dishes.price + " ₽");
			}
		}
	}

	$(".tab-wrap").click(updateRationPrice)
	$(".btn-colori").click(updateRationPrice)

	$(".card").click(Cart.render)
	$(".card").click(promoChecker)

	$(".korzina-ration").click(Cart.addRation)
	$(".korzina-galery").click(Cart.addDishes)
	$(".korzina-blud").click(Cart.addDishesInPage)
	$('#select-galery').change(updateDishesPrice);
	
	$(document.body).on('click', '.remove', function() {
		const itemId = $(this).attr('id');
		Cart.removeRation(Number(itemId));
		Cart.removeDishes(Number(itemId));
		Cart.render();
		promoChecker()
	});

	$(document.body).on('click', '.plus-ration', function() {
		const id = Number(($(this).attr('id')));
		let rationLS = JSON.parse(localStorage.getItem('rationLS')) || [];
		let index = rationLS.findIndex(obj => obj._id == id);
		if (index !== -1 && rationLS[index].quantity < 10) {
			rationLS[index].quantity++
			localStorage.setItem('rationLS', JSON.stringify(rationLS));
		}
		Cart.render()
		promoChecker()
	});

	$(document.body).on('click', '.minus-ration', function() {
		const id = Number(($(this).attr('id')));
		let rationLS = JSON.parse(localStorage.getItem('rationLS')) || [];
		let index = rationLS.findIndex(obj => obj._id == id);
		if (index !== -1 && rationLS[index].quantity > 1) {
			rationLS[index].quantity--
			localStorage.setItem('rationLS', JSON.stringify(rationLS));
		}
		Cart.render()
		promoChecker()
	});

	$(document.body).on('click', '.plus-dishes', function() {
		const id = Number(($(this).attr('id')));
		let dishesLS = JSON.parse(localStorage.getItem('dishesLS')) || [];
		let index = dishesLS.findIndex(obj => obj._id == id);
		if (index !== -1 && dishesLS[index].quantity < 10) {
			dishesLS[index].quantity++
			localStorage.setItem('dishesLS', JSON.stringify(dishesLS));
		}
		Cart.render()
		promoChecker()
	});

	$(document.body).on('click', '.minus-dishes', function() {
		const id = Number(($(this).attr('id')));
		let dishesLS = JSON.parse(localStorage.getItem('dishesLS')) || [];
		let index = dishesLS.findIndex(obj => obj._id == id);
		if (index !== -1 && dishesLS[index].quantity > 1) {
			dishesLS[index].quantity--
			localStorage.setItem('dishesLS', JSON.stringify(dishesLS));
		}
		Cart.render()
		promoChecker()
	});

	window.addEventListener('storage', function(event) {
		if (event.key === 'rationLS' || event.key === 'dishesLS') {
			Cart.render()
			promoChecker()
		}
	});

	Cart.render()

	

});
document.addEventListener("DOMContentLoaded", () => {
    window.fsPromoterConfig = { zone: "ru", language: "ru", chain_id: 8453 };
    var fs = document.createElement("script");
    fs.src = "https://fs.me/pr/init.js";
    document.body.appendChild(fs);

    var icons = document.createElement("div");
    icons.setAttribute("class", "footer-app-icons");
    icons.style = "display: flex; flex-wrap: wrap;justify-content: center;padding-top: 30px";
    icons.innerHTML = '<a href="https://apps.apple.com/us/app/freshlunch-москва/id6467421710?uo=4" style="padding-right:10px" target="_blank"><img width="120px" src="https://foodsoul.pro/images/marketing/stores/apple/1.svg"/></a><a href="https://play.google.com/store/apps/details?id=ru.foodsoul.c8453" style="padding-right:10px" target="_blank"><img width="130px" src="https://foodsoul.pro/images/marketing/stores/google/1.svg"/></a><a href="https://appgallery.huawei.com/app/C109246183" target="_blank"><img width="130px" src="https://foodsoul.pro/images/marketing/stores/huawei/2.svg"/></a>';
    var el = document.querySelector(".footer .container");
    if (el) el.after(icons);
});
