<?php

$url = 'https://crm.private-crm.ru/webApi/orderRequests/create';
$data = ['identifier' => 'mamacholi', 'webApiKey' => '9931f9cf-65fe-4d9f-bb77-0976175d0908', 'name' => 'value2', 'phone' => '89136638826'];

foreach ( $_POST as $key => $value ) {
	$data[$key] = $value;
}

$options = [
    'http' => [
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data),
    ],
];

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);
